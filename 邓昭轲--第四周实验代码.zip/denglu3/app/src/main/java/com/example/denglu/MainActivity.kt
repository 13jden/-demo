package com.example.denglu

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val img:ImageView=findViewById(R.id.imageView)
        img.setImageResource(R.drawable._1111)
      var button1:Button=findViewById(R.id.button1)
        button1.setOnClickListener {
            val edit: EditText = findViewById(R.id.editTextText) as EditText
            val edit2: EditText = findViewById(R.id.Password) as EditText
            val pass1 = "dengzhaoke"
            val pass2 = "2212190304"
            val name = edit.text.toString()
            val pass = edit2.text.toString()

            if (name == pass1 && pass == pass2) {
                val intent = Intent(this, MainActivity2::class.java)
                Toast.makeText(this, "恭喜你彭于晏，登陆成功！", Toast.LENGTH_SHORT).show()
                edit.setText("")
                edit2.setText("")
                startActivity(intent)
            } else {
                AlertDialog.Builder(this)
                    .setMessage("用户名或密码错误")
                    .setPositiveButton("确认") { dialogInterface: DialogInterface, _: Int ->
                        dialogInterface.dismiss()

                    }
                    .show()
                edit.setText("")
                edit2.setText("")
            }
        }

        var button2:Button=findViewById(R.id.button2)
            button2.setOnClickListener {
              finish()
            }
    }
}