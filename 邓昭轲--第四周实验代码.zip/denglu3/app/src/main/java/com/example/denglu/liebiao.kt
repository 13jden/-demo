package com.example.denglu

class liebiao(val imageResId: Int, val text: String, var text1:String,var type:Int)