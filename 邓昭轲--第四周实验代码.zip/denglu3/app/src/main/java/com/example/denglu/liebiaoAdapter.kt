package com.example.denglu
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import de.hdodenhof.circleimageview.CircleImageView

class LiebiaoAdapter(context: Context, private val dataList: List<liebiao>)
    : ArrayAdapter<liebiao>(context, 0, dataList) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.liebiao, parent, false)
        val imageView: CircleImageView = view.findViewById(R.id.touxiang)
        val textView0: TextView = view.findViewById(R.id.Name)
        val textView1:TextView =view.findViewById(R.id.textView)
        val item = getItem(position)

        item?.let {
            // 设置文本
            textView0.text = it.text
            textView1.text = it.text1
            // 设置图像资源
            if (it.imageResId != 0) {
                imageView.setImageResource(it.imageResId)
            }
        }

        return view
    }
    fun getItemImageResId(position: Int): Int {
        return dataList[position].imageResId
    }
    fun getItemText1(position: Int): String {
        return dataList[position].text1
    }
    fun getItemText(position: Int): String {
        return dataList[position].text
    }
    fun getItemType(position: Int):Int{
        return  dataList[position].type
    }
    fun setText1(position: Int,text :String,type:Int) {
        dataList[position].text1=text
        dataList[position].type=type

    }
}