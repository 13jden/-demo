package com.example.denglu

import android.app.Activity
import android.app.Application
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import msgAdapter

class MainActivity3 : AppCompatActivity(), View.OnClickListener {
    companion object {
        const val YOUR_REQUEST_CODE = 123 // 这里可以使用任何你想要的整数值
    }

    private val msgList = ArrayList<msg>()
    private var adapter: msgAdapter?=null
    private lateinit var recyclerView: RecyclerView
    private lateinit var send: Button // 将 send 声明为类的成员变量

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        // 接收来自 Activity2 传递过来的数据

        val name = intent.getStringExtra("name") ?: ""
        val title:TextView =findViewById(R.id.Title)

        title.text=name
        getSupportActionBar()?.setTitle(name)
        iniMsg()
        val layoutManager = LinearLayoutManager(this)
        recyclerView = findViewById(R.id.recyclerView) // 找到 recyclerView
        recyclerView.layoutManager = layoutManager

        adapter = msgAdapter(msgList)
        recyclerView.adapter = adapter
        send = findViewById(R.id.send) // 找到 send
        send.setOnClickListener(this)

        // 获取界面上的视图

    }

    override fun onClick(v: View?) {
        when(v){
            send -> {
                val editText: EditText = findViewById(R.id.editTextText)
                val content = editText.text.toString()

                if(content.isNotEmpty()){
                    val msgs=msg(content,R.drawable._1111,1)
                    msgList.add(msgs)
                    adapter?.notifyItemInserted(msgList.size-1)
                    recyclerView.scrollToPosition(msgList.size-1)
                    editText.setText("")
                }
            }
        }
    }


    private fun iniMsg() {
        val text = intent.getStringExtra("text") ?: ""
        val imageResId = intent.getIntExtra("imageResId", 0)
        val chuantype = intent.getIntExtra("chuantype", 0)
        val img: ImageView = findViewById(R.id.imge)

//        if (mydata.massages[dianjiid].isEmpty()) { // 检查数组是否为空
            img.setImageResource(imageResId)
            val msg1 = msg(text, imageResId, chuantype)
//            mydata.massages[dianjiid][0]=msg1// 将消息添加到数组中
            msgList.add(msg1)
//        } else {
//            mydata.massages[dianjiid].forEach { msgList.add(it) }
//        }
    }
    override fun onBackPressed() {//返回键 返回最后一条消息的内容
        val lastmsg = msgList.last().content
        val type =msgList.last().type
        val resultIntent = Intent()
        resultIntent.putExtra("lastmsg", lastmsg)
        resultIntent.putExtra("type", type)//类型

        setResult(Activity.RESULT_OK, resultIntent)
        //Toast.makeText(this, "$lastmsg", Toast.LENGTH_SHORT).show()
        finish()

    }


}

