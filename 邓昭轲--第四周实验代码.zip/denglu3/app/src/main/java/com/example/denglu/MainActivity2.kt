package com.example.denglu

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity2 : AppCompatActivity() {

    private lateinit var dataList: List<liebiao>
    private lateinit var adapter: LiebiaoAdapter
    var dianjiid:Int =-1
    private val REQUEST_CODE_ACTIVITY3 = 1 // 请求码用于启动 Activity3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        dataList = listOf(
            liebiao(R.drawable.qiqiang, "强总", "兄弟，风浪越大鱼越贵",0),
            liebiao(R.drawable.liuhuaqinag, "强哥", "你好，你这瓜保熟吗",0),
            liebiao(R.drawable.yousheng, "有胜", "师长，他们抢咱们东西",0),
            liebiao(R.drawable.youtian, "驾校李教练", "你知道京海车神是谁吗",0),
            liebiao(R.drawable.yunlong, "云龙哥", "你他娘还真是个人才",0),
            liebiao(R.drawable._1111, "我的电脑", "你好彭于晏",0)
        )

        adapter = LiebiaoAdapter(this, dataList)
        val listView: ListView = findViewById(R.id.listView)
        listView.adapter = adapter

        listView.setOnItemClickListener { parent, view, position, id ->

            val imageResId = adapter.getItemImageResId(position)
            val name = adapter.getItemText(position)
            val text = adapter.getItemText1(position)
            val chuantype = adapter.getItemType(position)
            dianjiid=position
            val intent = Intent(this, MainActivity3::class.java)
            intent.putExtra("chuantype",chuantype)
            intent.putExtra("text", text)
            intent.putExtra("imageResId", imageResId)
            intent.putExtra("name", name)
            intent.putExtra("position", position) // 传递列表项的位置

            startActivityForResult(intent, REQUEST_CODE_ACTIVITY3) // 启动 Activity3 并等待结果
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CODE_ACTIVITY3 && resultCode == Activity.RESULT_OK) {
            // 处理 Activity3 返回的数据
            val modifiedData = data?.getStringExtra("lastmsg")
            val type =data?.getIntExtra("type",0)
            //Toast.makeText(this, "$modifiedData", Toast.LENGTH_SHORT).show()
            if (modifiedData != null&&type != null) {
                    adapter.setText1(dianjiid,modifiedData,type)
                }
                dianjiid=-1
                adapter.notifyDataSetChanged()
            }
        }
    }

