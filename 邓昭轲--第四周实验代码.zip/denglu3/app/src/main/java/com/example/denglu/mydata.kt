package com.example.denglu

import android.app.Application

class mydata : Application() {
    companion object {
        lateinit var massages: Array<Array<msg>>
    }
    override fun onCreate() {
        super.onCreate()
        // 初始化二维数组
        massages = Array(10) { Array(10) { msg("", 0, 0) } }//存聊天信息
    }
}
