import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.denglu.R
import com.example.denglu.msg
import de.hdodenhof.circleimageview.CircleImageView
import java.lang.IllegalArgumentException

class msgAdapter(val msgList:List<msg>) :RecyclerView.Adapter<RecyclerView.ViewHolder>(){

    inner class LeftViewHolder(view: View):RecyclerView.ViewHolder(view){
        val leftmsg:TextView=view.findViewById(R.id.leftMsg)
    }
    inner class RightViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val rightmsg: TextView = view.findViewById(R.id.rightMsg)
    }


    override fun getItemViewType(position: Int): Int {

        val msg=msgList[position]
        return msg.type
    }

    override fun getItemCount(): Int {
       return msgList.size
    }



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)=if(viewType==msg.TYPE_RECEIVED)   {
        val view=LayoutInflater.from(parent.context).inflate(R.layout.msg_left,parent,false)
        LeftViewHolder(view)
    }else{
        val view=LayoutInflater.from(parent.context).inflate(R.layout.msg_right,parent,false)
        RightViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val msg = msgList[position]
        when (holder) {
            is LeftViewHolder -> holder.leftmsg.text = msg.content
            is RightViewHolder -> holder.rightmsg.text = msg.content
            else -> throw IllegalArgumentException("ViewHolder类型不匹配")
        }
    }


}


