package com.example.cameraalbumtest

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.ImageView
import android.widget.Toast

class ImgBroadcastReceiver(private val imageView: ImageView) : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == "com.example.cameraalbumtest.IMAGE_UPDATED") {
            val message = intent.getStringExtra("message")
            Toast.makeText(context,message, Toast.LENGTH_SHORT).show()
        }
    }
}
