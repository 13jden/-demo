package com.example.cameraalbumtest
import android.annotation.SuppressLint
import android.content.*
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var seekBar: SeekBar
    private lateinit var selectImageButton: Button
    private lateinit var adjustBrightnessButton: Button

    private lateinit var imageService: MyService
    private var serviceBound: Boolean = false

    private var selectedImageUri: Uri? = null
    private lateinit var adjustedBitmap: Bitmap

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as MyService.ImageBinder
            imageService = binder.getService()
            serviceBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
        }
    }

    private val imgBroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.d("Activity", "收到Broadcast")
            if (intent?.action == "com.example.cameraalbumtest.IMAGE_UPDATED") {
                // 接收到广播后
                imageView.setImageBitmap(adjustedBitmap)
            }
        }
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)
        seekBar = findViewById(R.id.seekbar)
        selectImageButton = findViewById(R.id.file)
        adjustBrightnessButton = findViewById(R.id.button)

        selectImageButton.setOnClickListener {
            openFileChooser()
        }

        adjustBrightnessButton.setOnClickListener {
            if (serviceBound && selectedImageUri != null) {
                val factor = seekBar.progress / 50f
                val inputStream = contentResolver.openInputStream(selectedImageUri!!)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                adjustedBitmap = imageService.adjustBrightness(bitmap, factor.toDouble())!!
//                imageView.setImageBitmap(adjustedBitmap)
            }
        }
    }

    private fun openFileChooser() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, REQUEST_CODE_PICK_IMAGE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_PICK_IMAGE && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                imageView.setImageURI(uri)
                selectedImageUri = uri
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Intent(this, MyService::class.java).also { intent ->
            bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        }
        val intentFilter = IntentFilter("com.example.cameraalbumtest.IMAGE_UPDATED")
        registerReceiver(imgBroadcastReceiver, intentFilter)
    }

    override fun onStop() {
        super.onStop()
        if (serviceBound) {
            unbindService(serviceConnection)
            serviceBound = false
        }
        unregisterReceiver(imgBroadcastReceiver)
    }

    companion object {
        private const val REQUEST_CODE_PICK_IMAGE = 100
    }
}
