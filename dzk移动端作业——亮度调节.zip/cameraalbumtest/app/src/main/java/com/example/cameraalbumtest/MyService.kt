package com.example.cameraalbumtest
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.os.Binder
import android.os.IBinder
import android.util.Log
import kotlin.math.pow

class MyService : Service() {

    private val binder = ImageBinder()

    inner class ImageBinder : Binder() {
        fun getService(): MyService {
            return this@MyService
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return binder
    }


    fun adjustBrightness(bitmap: Bitmap?, gamma: Double): Bitmap? {
        if (bitmap == null) {
            Log.e("ImageService", "Bitmap is null")
            return null
        }
        val width = bitmap.width
        val height = bitmap.height
        val result = Bitmap.createBitmap(width, height, bitmap.config)

        for (x in 0 until width) {
            for (y in 0 until height) {
                val color = bitmap.getPixel(x, y)
                val red = color and 0xFF
                val green = (color shr 8) and 0xFF
                val blue = (color shr 16) and 0xFF
                val alpha = color ushr 24

                val newRed = (red.toDouble() / 255.0).pow(gamma) * 255.0
                val newGreen = (green.toDouble() / 255.0).pow(gamma) * 255.0
                val newBlue = (blue.toDouble() / 255.0).pow(gamma) * 255.0

                val newColor = (alpha shl 24) or ((newRed.toInt() and 0xFF) shl 16) or
                        ((newGreen.toInt() and 0xFF) shl 8) or (newBlue.toInt() and 0xFF)

                result.setPixel(x, y, newColor)
            }
        }

//        val adjustedBitmap = adjustBrightness(scaledBitmap, gamma)
//        val intent = Intent("com.example.cameraalbumtest.IMAGE_UPDATED")
//            // 发送广播
//        intent.putExtra("bitmap", adjustedBitmap)
//        sendBroadcast(intent)

    val intent = Intent("com.example.cameraalbumtest.IMAGE_UPDATED")
    intent.putExtra("message", "图片处理完成")
    sendBroadcast(intent)

        Log.d("MyService", "Broadcast sent")

        return result
    }

}
