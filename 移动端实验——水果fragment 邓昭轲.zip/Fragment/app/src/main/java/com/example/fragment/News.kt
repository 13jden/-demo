package com.example.fragment

class News(val title:String,val content:Int,val imageID : Int)
//