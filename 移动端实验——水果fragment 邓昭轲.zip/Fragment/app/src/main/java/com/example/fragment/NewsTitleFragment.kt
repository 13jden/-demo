package com.example.fragment

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.lang.StringBuilder

class NewsTitleFragment: Fragment() {
    private var isTwoPane = false
    private lateinit var recyclerView: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.news_title_frag, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView = view.findViewById(R.id.newsTitleRecyclerview)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        isTwoPane = activity?.findViewById<View>(R.id.contentLayout) != null

        val layoutManager = LinearLayoutManager(activity)
        recyclerView.layoutManager = layoutManager
        recyclerView.adapter = NewsAdapter(getNews())
    }

    private fun getNews(): List<News> {
        return listOf(
            News("Apple         14RMB/kg", 14, R.drawable.apple_pic),
            News("Banana        21RMB/kg", 21, R.drawable.banana_pic),
            News("Cherry        14RMB/kg", 14, R.drawable.cherry_pic),
            News("Grape         21RMB/kg", 21, R.drawable.grape_pic),
            News("Orange        35RMB/kg", 35, R.drawable.orange_pic),
            News("Mango         28RMB/kg", 28, R.drawable.mango_pic),
            News("Pear          35RMB/kg", 35, R.drawable.pear_pic),
            News("Pineapple     42RMB/kg", 42, R.drawable.pineapple_pic),
            News("Strawberry    50RMB/kg", 50, R.drawable.strawberry_pic),
            News("Watermelon    15RMB/kg", 15, R.drawable.watermelon_pic)
        )
    }


    private fun getRandomLengthString(str: String): String {
        val n = (1..30).random()
        val builder = StringBuilder()
        repeat(n) {
            builder.append(str)
        }
        return builder.toString()
    }

    inner class NewsAdapter(val newsList: List<News>): RecyclerView.Adapter<NewsAdapter.ViewHolder>() {

        inner class ViewHolder(view: View): RecyclerView.ViewHolder(view) {
            val newsTitle = view.findViewById<TextView>(R.id.newsItemTitle)
            val newsImage: ImageView = view.findViewById(R.id.image)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.news_item, parent, false)
            val holder = ViewHolder(view)
            holder.itemView.setOnClickListener {
                val news = newsList[holder.adapterPosition]

                if (isTwoPane) {
                    Log.d("我是平板", "Clicked News Title: ${news.title}, Content: ${news.content}")
                    val fragment = requireActivity().supportFragmentManager.
                    findFragmentById(R.id.newsContentFrag) as? NewsContentFragment
                    if (fragment == null) {
                        Log.d("空的啊", "NewsContentFragment is null.")
                    } else {
                        Log.d("不为空", "NewsContentFragment is not null.")
                        fragment.refresh(news.title, news.content,news.imageID)
                    }

                } else {
                    Log.d("我是手机","Clicked News Title: ${news.title}")

                    NewsContentActivity.actionStart(parent.context, news.title, news.content,news.imageID)
                }
            }
            return holder
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val news = newsList[position]
            holder.newsTitle.text = news.title
            holder.newsImage.setImageResource(news.imageID);
        }

        override fun getItemCount() = newsList.size
    }
}
