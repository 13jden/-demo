package com.example.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class NewsContentFragment : Fragment() {

    private var title: String? = null
    private var content: Int? = null
    private var imageID: Int? = null
    private var n: Int = 0

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.news_content_frag, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // 在视图创建完毕后更新UI
        title?.let { t ->
            content?.let { c ->
                imageID?.let { img -> // 确保imageResId不为空
                    refresh(t, c, img)
                }
            }
        }

        // 找到按钮并设置点击事件监听器
        view.findViewById<Button>(R.id.button1)?.setOnClickListener {
            if(n>0) {
                n--
                Toast.makeText(context, "多买点呗", Toast.LENGTH_SHORT).show()
            }
            else{
                Toast.makeText(context, "负数了哦", Toast.LENGTH_SHORT).show()
            }
            refresh(title ?: "", content ?: 0, imageID ?: 0) // 更新UI
        }

        view.findViewById<Button>(R.id.button2)?.setOnClickListener {
            n++
            Toast.makeText(context, "老板继续！", Toast.LENGTH_SHORT).show()
            refresh(title ?: "", content ?: 0, imageID ?: 0) // 更新UI
        }
    }

    fun refresh(title: String, content: Int, imageID: Int) {
        this.title = title
        this.content = content
        this.imageID = imageID
        Log.d("refresh调用", "成功")
        view?.let {
            val linearLayout = it.findViewById<LinearLayout>(R.id.contentLayout)
            linearLayout?.apply {
                visibility = View.VISIBLE
                val titleText = findViewById<TextView>(R.id.newsTitle)
                titleText.text = title
                val contentText = findViewById<TextView>(R.id.newsContent)

                contentText.text = "购买了"+n+"kg，价格是" + content * n + "元"
                val contentimage = findViewById<ImageView>(R.id.contentimage)
                contentimage.setImageResource(imageID)
            }
        }
    }
}
