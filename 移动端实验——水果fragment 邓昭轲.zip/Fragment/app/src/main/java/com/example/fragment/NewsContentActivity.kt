package com.example.fragment

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log


class NewsContentActivity : AppCompatActivity() {
    companion object{
        fun actionStart(context:Context,title:String,content:Int,imageID:Int){
            val intent=Intent(context,NewsContentActivity::class.java).apply {
                putExtra("news_title",title)
                putExtra("news_content",content)
                putExtra("news_image",imageID)
            }
            context.startActivity(intent)

        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news_content)
        val title=intent.getStringExtra("news_title")
        val content=intent.getIntExtra("news_content",0)
        val imageID=intent.getIntExtra("news_image",0)
        Log.d("image", imageID.toString())
        if(title!=null&&content!=null&&imageID!=null){
            val fragment=supportFragmentManager.findFragmentById(R.id.newsContentFrag) as NewsContentFragment
            Log.d("Yes","yes yes $title okok $content  $imageID")
            fragment.refresh(title,content,imageID)
        }
    }
}