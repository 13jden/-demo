package com.example.shuju

import android.content.ContentProvider
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.net.Uri

class MyContentProvider : ContentProvider() {

    private val STUDENT_DIR = 0
    private val STUDENT_ITEM = 1
    private val AUTHORITY = "com.example.shuju.provider"
    private var dbHelper: MyDatabaseHelper? = null
    private var uriMatcher: UriMatcher? = null

    override fun onCreate(): Boolean {
        dbHelper = MyDatabaseHelper(context!!, "Students.db", 1)
        uriMatcher = UriMatcher(UriMatcher.NO_MATCH)
        uriMatcher!!.addURI(AUTHORITY, "Student", STUDENT_DIR)
        uriMatcher!!.addURI(AUTHORITY, "Student/#", STUDENT_ITEM)
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<String?>?,
        selection: String?,
        selectionArgs: Array<String?>?,
        sortOrder: String?
    ): Cursor? {
        val db = dbHelper!!.readableDatabase
        var cursor: Cursor? = null
        when (uriMatcher!!.match(uri)) {
            STUDENT_DIR -> cursor =
                db.query("Student", projection, selection, selectionArgs, null, null, sortOrder)

            STUDENT_ITEM -> {
                val studentId = uri.pathSegments[1]
                cursor = db.query(
                    "Student",
                    projection,
                    "id = ?",
                    arrayOf(studentId),
                    null,
                    null,
                    sortOrder
                )
            }

            else -> {}
        }
        return cursor
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        val db = dbHelper!!.writableDatabase
        var uriReturn: Uri? = null
        when (uriMatcher!!.match(uri)) {
            STUDENT_DIR, STUDENT_ITEM -> {
                val newStudentId = db.insert("Student", null, values)
                uriReturn = Uri.parse("content://$AUTHORITY/Student/$newStudentId")
            }

            else -> {}
        }
        return uriReturn
    }

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<String?>?
    ): Int {
        val db = dbHelper!!.writableDatabase
        var updatedRows = 0
        when (uriMatcher!!.match(uri)) {
            STUDENT_DIR -> updatedRows = db.update("Student", values, selection, selectionArgs)
            STUDENT_ITEM -> {
                val studentId = uri.pathSegments[1]
                updatedRows = db.update("Student", values, "id = ?", arrayOf(studentId))
            }

            else -> {}
        }
        return updatedRows
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String?>?): Int {
        val db = dbHelper!!.writableDatabase
        var deletedRows = 0
        when (uriMatcher!!.match(uri)) {
            STUDENT_DIR -> deletedRows = db.delete("Student", selection, selectionArgs)
            STUDENT_ITEM -> {
                val studentId = uri.pathSegments[1]
                deletedRows = db.delete("Student", "id = ?", arrayOf(studentId))
            }

            else -> {}
        }
        return deletedRows
    }

    override fun getType(uri: Uri): String? {
        return when (uriMatcher?.match(uri)) {
            STUDENT_DIR -> "vnd.android.cursor.dir/vnd.$AUTHORITY.Student"
            STUDENT_ITEM -> "vnd.android.cursor.item/vnd.$AUTHORITY.Student"
            else -> null
        }
    }

}