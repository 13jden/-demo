package com.example.shuju

class Student(val name: String, val xuehao: String, val xueyuan: String)