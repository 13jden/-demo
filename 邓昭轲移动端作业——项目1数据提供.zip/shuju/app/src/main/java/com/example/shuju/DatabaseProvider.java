package com.example.shuju;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

import androidx.annotation.NonNull;

public class DatabaseProvider extends ContentProvider {
    private static final int STUDENT_DIR = 0;
    private static final int STUDENT_ITEM = 1;
    private static final String AUTHORITY = "com.example.shuju.provider";
    private MyDatabaseHelper dbHelper;
    private UriMatcher uriMatcher;

    @Override
    public boolean onCreate() {
        dbHelper = new MyDatabaseHelper(getContext(), "School.db", 1);
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(AUTHORITY, "student", STUDENT_DIR);
        uriMatcher.addURI(AUTHORITY, "student/#", STUDENT_ITEM);
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        switch (uriMatcher.match(uri)) {
            case STUDENT_DIR:
                cursor = db.query("Student", projection, selection, selectionArgs, null, null, sortOrder);
                break;
            case STUDENT_ITEM:
                String studentId = uri.getPathSegments().get(1);
                cursor = db.query("Student", projection, "id = ?", new String[]{studentId}, null, null, sortOrder);
                break;
            default:
                break;
        }
        return cursor;
    }

    @Override
    public Uri insert(@NonNull Uri uri, ContentValues values) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Uri uriReturn = null;
        switch (uriMatcher.match(uri)) {
            case STUDENT_DIR:
            case STUDENT_ITEM:
                long newStudentId = db.insert("Student", null, values);
                uriReturn = Uri.parse("content://" + AUTHORITY + "/student/" + newStudentId);
                break;
            default:
                break;
        }
        return uriReturn;
    }

    @Override
    public int update(@NonNull Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int updatedRows = 0;
        switch (uriMatcher.match(uri)) {
            case STUDENT_DIR:
                updatedRows = db.update("Student", values, selection, selectionArgs);
                break;
            case STUDENT_ITEM:
                String studentId = uri.getPathSegments().get(1);
                updatedRows = db.update("Student", values, "id = ?", new String[]{studentId});
                break;
            default:
                break;
        }
        return updatedRows;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int deletedRows = 0;
        switch (uriMatcher.match(uri)) {
            case STUDENT_DIR:
                deletedRows = db.delete("Student", selection, selectionArgs);
                break;
            case STUDENT_ITEM:
                String studentId = uri.getPathSegments().get(1);
                deletedRows = db.delete("Student", "id = ?", new String[]{studentId});
                break;
            default:
                break;
        }
        return deletedRows;
    }

    @Override
    public String getType(Uri uri) {
        switch (uriMatcher.match(uri)) {
            case STUDENT_DIR:
                return "vnd.android.cursor.dir/vnd." + AUTHORITY + ".student";
            case STUDENT_ITEM:
                return "vnd.android.cursor.item/vnd." + AUTHORITY + ".student";
            default:
                return null;
        }
    }
}
