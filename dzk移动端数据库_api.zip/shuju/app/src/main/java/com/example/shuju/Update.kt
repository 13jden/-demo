package com.example.shuju

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.shuju.RetrofitClient.apiService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Update : AppCompatActivity() {
    @SuppressLint("Range", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update)
        Log.d("传到update","okok")
        val studentId = intent.getIntExtra("student_id", 0) // 默认值为0，或者您可以根据实际情况设置其他默认值
        val studentName = intent.getStringExtra("student_name")
        val studentDept = intent.getStringExtra("student_dept")
        val studentAge = intent.getIntExtra("student_age", 0)
        val studentPhone = intent.getStringExtra("student_phone")
        val name: EditText = findViewById(R.id.name)
        val xuehao: TextView = findViewById(R.id.xuehao)
        val xueyuan: EditText = findViewById(R.id.xueyuan)
        val age: EditText = findViewById(R.id.age)
        val phone: EditText = findViewById(R.id.phone)

        name.setText(studentName)
        xuehao.setText(studentId.toString())
        xueyuan.setText(studentDept)
        age.setText(studentAge.toString())
        phone.setText(studentPhone)
        val update:Button=findViewById(R.id.button2)
        val delete:Button=findViewById(R.id.button3)
        update.setOnClickListener {
            val studentId = xuehao.text.toString()
            val studentName = name.text.toString()
            val studentDept = xueyuan.text.toString()
            val studentAge = age.text.toString()
            val studentPhone = phone.text.toString()

            apiService.updateStudent(studentId, studentName, studentDept, studentAge, studentPhone)
                .enqueue(object : Callback<Int> {
                    override fun onResponse(call: Call<Int>, response: Response<Int>) {
                        if (response.isSuccessful) {
                            val result = response.body()
                            if (result != null) {
                                // 请求成功，打印返回的结果
                                Log.d("Insert Success", "Result: $result")
                                Toast.makeText(this@Update, "修改成功", Toast.LENGTH_SHORT).show()
                                val intent = Intent(this@Update, MainActivity::class.java)
                                startActivity(intent)
                            } else {
                                // 请求成功，但返回结果为空
                                Log.e("Insert Error", "Response body is null")
                            }
                        } else {
                            // 请求失败，打印错误信息
                            Log.e("Insert Error", "Request failed with code: ${response.code()}")
                        }
                    }

                    override fun onFailure(call: Call<Int>, t: Throwable) {
                        // 请求失败，打印错误信息
                        Log.e("Insert Error", "Request failed: ${t.message}")
                    }
                })
        }


        delete.setOnClickListener {
            val studentId = xuehao.text.toString()

            apiService.deleteStudent(studentId)
                .enqueue(object : Callback<Int> {
                    override fun onResponse(call: Call<Int>, response: Response<Int>) {
                        if (response.isSuccessful) {
                            val result = response.body()
                            if (result != null) {
                                // 请求成功，打印返回的结果
                                Log.d("Delete Success", "Result: $result")
                                Toast.makeText(this@Update, "删除成功", Toast.LENGTH_SHORT).show()
                                val intent = Intent(this@Update, MainActivity::class.java)
                                startActivity(intent)
                            } else {
                                // 请求成功，但返回结果为空
                                Log.e("Delete Error", "Response body is null")
                            }
                        } else {
                            // 请求失败，打印错误信息
                            Log.e("Delete Error", "Request failed with code: ${response.code()}")
                        }
                    }

                    override fun onFailure(call: Call<Int>, t: Throwable) {
                        // 请求失败，打印错误信息
                        Log.e("Delete Error", "Request failed: ${t.message}")
                    }
                })


        }

        }
}
