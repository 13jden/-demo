package com.example.shuju
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import org.xml.sax.Attributes
import org.xml.sax.InputSource
import okhttp3.ResponseBody
import org.xml.sax.SAXException
import org.xml.sax.helpers.DefaultHandler
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.simplexml.SimpleXmlConverterFactory
import java.io.StringReader
import javax.xml.parsers.SAXParserFactory

class Query : AppCompatActivity() {
    private val retrofit = Retrofit.Builder()
        .baseUrl("http://2452x7g449.wicp.vip:9998")
        .addConverterFactory(SimpleXmlConverterFactory.create())
        .build()

    private val apiService = retrofit.create(ApiService::class.java)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_query)

        val listView: ListView = findViewById(R.id.listView)

        // 发起查询请求
        apiService.queryStudents().enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful) {
                    val xmlData = response.body()?.string()
                    if (!xmlData.isNullOrEmpty()) {
                        val parser = XmlSaxParser()
                        val students = parser.parse(xmlData)
                        if (students.isNotEmpty()) {
                            val dataList = students.map { student ->
                                "姓名：${student.name}\n学号：${student.id}\n学院：${student.dept}"
                            }
                            val adapter = ArrayAdapter(this@Query, android.R.layout.simple_list_item_1, dataList)
                            listView.adapter = adapter
                            // 设置点击事件监听器
                            listView.setOnItemClickListener { parent, view, position, id ->
                                val selectedStudent = students[position]
                                // 将选定的学生信息传递到 UpdateActivity
                                val intent = Intent(this@Query, Update::class.java).apply {
                                    putExtra("student_id", selectedStudent?.id ?: "")
                                    putExtra("student_name", selectedStudent?.name ?: "")
                                    putExtra("student_dept", selectedStudent?.dept ?: "")
                                    putExtra("student_age", selectedStudent?.age ?: "")
                                    putExtra("student_phone", selectedStudent?.phone ?: "")
                                }

                                startActivity(intent)
                            }
                        } else {
                            Toast.makeText(this@Query, "学生列表为空", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this@Query, "XML 数据为空", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this@Query, "网络请求失败", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Toast.makeText(this@Query, "网络请求失败", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
//SAX解析xml
class XmlSaxParser : DefaultHandler() {
    private val students = mutableListOf<Student>()
    private var currentStudent: Student? = null
    private var currentElement = ""

    fun parse(xmlData: String): List<Student> {
        val factory = SAXParserFactory.newInstance()
        val parser = factory.newSAXParser()
        val reader = StringReader(xmlData)
        parser.parse(InputSource(reader), this)
        return students
    }

    override fun startElement(uri: String?, localName: String?, qName: String?, attributes: Attributes?) {
        currentElement = qName ?: ""
        if (currentElement == "Table") {
            currentStudent = Student()
        }
    }

    override fun characters(ch: CharArray?, start: Int, length: Int) {
        val value = String(ch!!, start, length).trim()
        when (currentElement) {
            "id" -> currentStudent?.id = value.toInt()
            "name" -> currentStudent?.name = value
            "dept" -> currentStudent?.dept = value
            "age" -> currentStudent?.age = value.toInt()
            "phone" -> currentStudent?.phone = value
        }
    }

    override fun endElement(uri: String?, localName: String?, qName: String?) {
        if (qName == "Table") {
            students.add(currentStudent!!)
            currentStudent = null
        }
        currentElement = ""
    }
}
