package com.example.shuju

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface ApiService {
    @FormUrlEncoded
    @POST("/Service1.asmx/updateStudent")
    fun updateStudent(
        @Field("id") id: String,
        @Field("name") name: String,
        @Field("dept") dept: String,
        @Field("age") age: String,
        @Field("phone") phone: String
    ): Call<Int>


    @POST("/Service1.asmx/QueryStudents")
    fun queryStudents(): Call<ResponseBody>


    @FormUrlEncoded
    @POST("/Service1.asmx/deleteStudent")
    fun deleteStudent(
        @Field("id") id: String
    ): Call<Int>

    @FormUrlEncoded
    @POST("/Service1.asmx/insertStudent")
    fun insertStudent(
        @Field("name") name: String,
        @Field("dept") dept: String,
        @Field("age") age: String,
        @Field("phone") phone: String
    ): Call<Int>
}
