package com.example.shuju
import org.simpleframework.xml.Element
import org.simpleframework.xml.ElementList
import org.simpleframework.xml.Namespace
import org.simpleframework.xml.Root

@Root(name = "NewDataSet")
data class StudentDataSet(
    @field:ElementList(inline = true, entry = "Table")
    var students: List<Student>? = null
)

@Root(name = "Table")
data class Student(
    @field:Element(name = "id")
    var id: Int? = null,

    @field:Element(name = "name")
    var name: String? = null,

    @field:Element(name = "dept")
    var dept: String? = null,

    @field:Element(name = "age")
    var age: Int? = null,

    @field:Element(name = "phone")
    var phone: String? = null
)
