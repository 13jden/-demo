package com.example.shuju

//class Student(val name: String, val id: String, val dept: String,val age:String,val phone:String)