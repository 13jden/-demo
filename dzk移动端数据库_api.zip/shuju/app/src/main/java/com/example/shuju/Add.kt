package com.example.shuju
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.simplexml.SimpleXmlConverterFactory

class Add : AppCompatActivity() {
    private val retrofit = Retrofit.Builder()
        .baseUrl("http://2452x7g449.wicp.vip:9998")
        .addConverterFactory(SimpleXmlConverterFactory.create())
        .build()

    private val apiService = retrofit.create(ApiService::class.java)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        val addData: Button = findViewById(R.id.button)
        val editText2 : EditText = findViewById(R.id.name)
        val editText3 : EditText = findViewById(R.id.xueyuan)
        val editText4 : EditText = findViewById(R.id.age)
        val editText5 : EditText = findViewById(R.id.phone)

        addData.setOnClickListener {

            val name = editText2.text.toString()
            val dept = editText3.text.toString()
            val age = editText4.text.toString()
            val phone = editText5.text.toString()

            apiService.insertStudent(name, dept, age, phone).enqueue(object : Callback<Int> {
                override fun onResponse(call: Call<Int>, response: Response<Int>) {
                    if (response.isSuccessful) {
                        val result = response.body()
                        if (result != null) {
                            // 请求成功，打印返回的结果
                            Log.d("Insert Success", "Result: $result")
                            Toast.makeText(this@Add, "修改成功", Toast.LENGTH_SHORT).show()
                            val intent = Intent(this@Add, MainActivity::class.java)
                            startActivity(intent)
                        } else {
                            // 请求成功，但返回结果为空
                            Log.e("Insert Error", "Response body is null")
                        }
                    } else {
                        // 请求失败，打印错误信息
                        Log.e("Insert Error", "Request failed with code: ${response.code()}")
                    }
                }

                override fun onFailure(call: Call<Int>, t: Throwable) {
                    // 网络请求失败，打印错误信息
                    Log.e("Insert Error", "Failed to make network request", t)
                }
            })

        }
    }
}
