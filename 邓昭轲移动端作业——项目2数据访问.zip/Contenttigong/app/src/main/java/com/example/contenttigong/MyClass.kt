package com.example.contenttigong

class MyClass {

    val p by Delegate()

}