package com.example.contenttigong
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import android.database.CursorIndexOutOfBoundsException

class Query : AppCompatActivity() {
    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_query)
        Log.d("进入Query", "ListView set up successfully.")
        val listView: ListView = findViewById(R.id.listView)
        Log.d("Cursor Debug", "onCreate started.")
        val cursor = contentResolver.query(
            Uri.parse("content://com.example.shuju.provider/Student"),
            null,
            null,
            null,
            null
        )

        val dataList = mutableListOf<String>()
        while (cursor?.moveToNext()!!) {
            val nameIndex = cursor.getColumnIndex("name")
            val xuehaoIndex = cursor.getColumnIndex("xuehao")
            val xueyuanIndex = cursor.getColumnIndex("xueyuan")

            if (nameIndex != -1 && xuehaoIndex != -1 && xueyuanIndex != -1) {
                val name = cursor.getString(nameIndex)
                val xuehao = cursor.getString(xuehaoIndex)
                val xueyuan = cursor.getString(xueyuanIndex)
                val item = "姓名：$name\n学号：$xuehao\n学院：$xueyuan"
                dataList.add(item)
            }
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, dataList)
        listView.adapter = adapter

        listView.setOnItemClickListener { parent, view, position, id ->
            cursor.moveToPosition(position)
            Log.d("点击成功，识别点击学号", "okok")
            val xuehaoIndex = cursor.getColumnIndex("xuehao")
            val xuehao = cursor.getString(xuehaoIndex)

            val intent = Intent(this, Update::class.java)
            intent.putExtra("xuehao", xuehao)
            Log.d("传值成功准备跳转", "okok")
            cursor.close()
            startActivity(intent)

        }
    }
}

