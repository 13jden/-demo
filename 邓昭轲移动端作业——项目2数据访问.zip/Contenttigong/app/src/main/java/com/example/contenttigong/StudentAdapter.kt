package com.example.contenttigong
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class StudentAdapter(private val context: Context, private val students: List<Student>) : BaseAdapter() {

    override fun getCount(): Int {
        return students.size
    }

    override fun getItem(position: Int): Any {
        return students[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view = convertView
        val viewHolder: ViewHolder
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.searchbiao, parent, false)
            viewHolder = ViewHolder()
            viewHolder.nameTextView = view.findViewById(R.id.name)
            viewHolder.xuehaoTextView = view.findViewById(R.id.xuehao)
            viewHolder.xueyuanTextView = view.findViewById(R.id.xueyuan)
            view.tag = viewHolder
        } else {
            viewHolder = view.tag as ViewHolder
        }

        val student = getItem(position) as Student
        viewHolder.nameTextView.text = student.name
        viewHolder.xuehaoTextView.text = student.xuehao
        viewHolder.xueyuanTextView.text = student.xueyuan

        return view!!
    }

    private class ViewHolder {
        lateinit var nameTextView: TextView
        lateinit var xuehaoTextView: TextView
        lateinit var xueyuanTextView: TextView
    }
}
