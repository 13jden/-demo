package com.example.contenttigong

class Student(val name: String, val xuehao: String, val xueyuan: String)