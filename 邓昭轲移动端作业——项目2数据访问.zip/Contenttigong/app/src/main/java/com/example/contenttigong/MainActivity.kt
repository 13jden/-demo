package com.example.contenttigong

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    var studentId: String? = null

    @SuppressLint("Range", "Recycle")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val addData = findViewById<Button>(R.id.addData)
        val queryData = findViewById<Button>(R.id.queryData)

        addData.setOnClickListener {
            val intent = Intent(this, Add::class.java)
            startActivity(intent)
        }

     
        queryData.setOnClickListener {
            val intent = Intent(this, Query::class.java)
            startActivity(intent)

        }



    }
}


