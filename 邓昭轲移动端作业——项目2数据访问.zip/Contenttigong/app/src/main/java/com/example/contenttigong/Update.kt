package com.example.contenttigong
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
class Update : AppCompatActivity() {
    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update)

        val xuehao = intent.getStringExtra("xuehao")
        findViewById<EditText>(R.id.xuehao).setText(xuehao)

        val cursor = contentResolver.query(
            Uri.parse("content://com.example.shuju.provider/student"),
            null,
            "xuehao = ?",
            arrayOf(xuehao),
            null
        )

        cursor?.use {
            if (it.moveToFirst()) {
                val name = it.getString(it.getColumnIndexOrThrow("name"))
                val xueyuan = it.getString(it.getColumnIndexOrThrow("xueyuan"))
                val age = it.getString(it.getColumnIndexOrThrow("age"))
                val dianhua = it.getString(it.getColumnIndexOrThrow("dianhua"))

                findViewById<EditText>(R.id.name).setText(name)
                findViewById<EditText>(R.id.xueyuan).setText(xueyuan)
                findViewById<EditText>(R.id.age).setText(age)
                findViewById<EditText>(R.id.dianhua).setText(dianhua)
            }
        }

        findViewById<Button>(R.id.button2).setOnClickListener {
            updateStudent(xuehao)
        }

        findViewById<Button>(R.id.button3).setOnClickListener {
            deleteStudent(xuehao)
        }
    }

    private fun getFieldText(id: Int): String {
        return findViewById<EditText>(id).text.toString()
    }

    private fun updateStudent(xuehao: String?) {
        val values = ContentValues().apply {
            put("name", getFieldText(R.id.name))
            put("xueyuan", getFieldText(R.id.xueyuan))
            put("age", getFieldText(R.id.age))
            put("dianhua", getFieldText(R.id.dianhua))
        }

        val uri = Uri.parse("content://com.example.shuju.provider/student/$xuehao")
        val rowsAffected = contentResolver.update(uri, values, null, null)

        if (rowsAffected > 0) {
            Toast.makeText(this, "修改成功", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, MainActivity::class.java))
        } else {
            Toast.makeText(this, "修改失败", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteStudent(xuehao: String?) {
        val uri = Uri.parse("content://com.example.shuju.provider/student/$xuehao")
        val rowsAffected = contentResolver.delete(uri, null, null)

        if (rowsAffected > 0) {
            Toast.makeText(this, "删除成功", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, MainActivity::class.java))
        } else {
            Toast.makeText(this, "删除失败", Toast.LENGTH_SHORT).show()
        }
    }
}
