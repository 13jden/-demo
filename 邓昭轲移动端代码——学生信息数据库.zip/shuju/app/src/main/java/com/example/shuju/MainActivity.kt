package com.example.shuju
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.contentValuesOf
import java.io.Serializable

class MainActivity : AppCompatActivity() {

    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val dbHelper = MyDatabaseHelper(this, "Students.db", 3)
        val createDatabase: Button = findViewById(R.id.createDatabase)
        createDatabase.setOnClickListener {
            dbHelper.writableDatabase
            Toast.makeText(this, "创建成功", Toast.LENGTH_SHORT).show()
        }
        contentValuesOf("" to "")
        val addData: Button = findViewById(R.id.addData)
        addData.setOnClickListener {
            val intent = Intent(this, Add::class.java)
            startActivity(intent)

        }

        val queryData: Button = findViewById(R.id.queryData)
        queryData.setOnClickListener {
            val intent = Intent(this, Query::class.java)
            startActivity(intent)

        }
    }
}
