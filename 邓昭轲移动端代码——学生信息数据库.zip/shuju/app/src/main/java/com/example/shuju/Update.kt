package com.example.shuju

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Update : AppCompatActivity() {
    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update)
        Log.d("传到update","okok")

        val xuehao = intent.getStringExtra("xuehao")
        findViewById<EditText>(R.id.xuehao).setText(xuehao)

        val dbHelper = MyDatabaseHelper(this, "Students.db", 3)
        val db = dbHelper.readableDatabase
        val cursor = db.query("Student", null, "xuehao = ?", arrayOf(xuehao), null, null, null)
        if (cursor.moveToFirst()) {

            val name = cursor.getString(cursor.getColumnIndex("name"))
            val xueyuan = cursor.getString(cursor.getColumnIndex("xueyuan"))
            val age = cursor.getString(cursor.getColumnIndex("age"))
            val dianhua = cursor.getString(cursor.getColumnIndex("dianhua"))
            findViewById<EditText>(R.id.name).setText(name)
            findViewById<EditText>(R.id.xueyuan).setText(xueyuan)
            findViewById<EditText>(R.id.age).setText(age)
            findViewById<EditText>(R.id.dianhua).setText(dianhua)
        }

        cursor.close()
        db.close()
        findViewById<Button>(R.id.button2).setOnClickListener {
            updateStudent(dbHelper, xuehao)
        }

        findViewById<Button>(R.id.button3).setOnClickListener {
            deleteStudent(dbHelper, xuehao)
        }
    }

    private fun updateStudent(dbHelper: MyDatabaseHelper, xuehao: String?) {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("name", findViewById<EditText>(R.id.name).text.toString())
            put("xueyuan", findViewById<EditText>(R.id.xueyuan).text.toString())
            put("age", findViewById<EditText>(R.id.age).text.toString())
            put("dianhua", findViewById<EditText>(R.id.dianhua).text.toString())
        }
        db.update("Student", values, "xuehao = ?", arrayOf(xuehao))
        db.close()
        Toast.makeText(this, "修改成功", Toast.LENGTH_SHORT).show()
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    private fun deleteStudent(dbHelper: MyDatabaseHelper, xuehao: String?) {
        val db = dbHelper.writableDatabase
        db.delete("Student", "xuehao = ?", arrayOf(xuehao))
        db.close()
        Toast.makeText(this, "删除成功", Toast.LENGTH_SHORT).show()
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}
