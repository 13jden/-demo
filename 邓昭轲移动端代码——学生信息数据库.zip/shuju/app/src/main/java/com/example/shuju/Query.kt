package com.example.shuju

import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class Query : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_query)

        val listView: ListView = findViewById(R.id.listView)
        val dbHelper = MyDatabaseHelper(this, "Students.db", 3)

        val db = dbHelper.readableDatabase
        val cursor = db.query("Student", null, null, null, null, null, null)

        val dataList = mutableListOf<String>()
        while (cursor.moveToNext()) {
            val nameIndex = cursor.getColumnIndex("name")
            val xuehaoIndex = cursor.getColumnIndex("xuehao")
            val xueyuanIndex = cursor.getColumnIndex("xueyuan")

            if (nameIndex != -1 && xuehaoIndex != -1 && xueyuanIndex != -1) {
                val name = cursor.getString(nameIndex)
                val xuehao = cursor.getString(xuehaoIndex)
                val xueyuan = cursor.getString(xueyuanIndex)
                val item = "姓名：$name\n学号：$xuehao\n学院：$xueyuan"
                dataList.add(item)
            }
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, dataList)
        listView.adapter = adapter

        listView.setOnItemClickListener { parent, view, position, id ->
            cursor.moveToPosition(position)
            Log.d("点击成功，识别点击学号","okok")
            val xuehaoIndex = cursor.getColumnIndex("xuehao")
            val xuehao = cursor.getString(xuehaoIndex)

            val intent = Intent(this, Update::class.java)
            intent.putExtra("xuehao", xuehao)
            Log.d("传值成功准备跳转","okok")
            cursor.close()
            db.close()
            startActivity(intent)

        }

    }

}
