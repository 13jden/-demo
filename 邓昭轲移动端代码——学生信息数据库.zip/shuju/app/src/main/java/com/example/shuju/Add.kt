package com.example.shuju
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class Add : AppCompatActivity() {
    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)
        val dbHelper = MyDatabaseHelper(this, "Students.db", 3)

        val addData: Button = findViewById(R.id.button)
        val editText1 : EditText = findViewById(R.id.xuehao)
        val editText2 : EditText = findViewById(R.id.name)
        val editText3 : EditText = findViewById(R.id.xueyuan)
        val editText4 : EditText = findViewById(R.id.age)
        val editText5 : EditText = findViewById(R.id.phone)
        addData.setOnClickListener {
            val db = dbHelper.writableDatabase
            val values1 = ContentValues().apply {
                val xuehao = editText1.text.toString()
                val name = editText2.text.toString()
                val xueyuan = editText3.text.toString()
                val age = editText4.text.toString()
                val dianhua = editText5.text.toString()
                put("xuehao", xuehao)
                put("name", name)
                put("xueyuan", xueyuan)
                put("age", age)
                put("dianhua",dianhua)


            }
            val newRowId = db.insert("Student", null, values1)
            db.close()

            // 显示 Toast 提示用户添加成功
            if (newRowId != -1L) {
                Toast.makeText(this, "添加成功", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "添加失败", Toast.LENGTH_SHORT).show()
            }

            // 跳转到 MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}
